import os
import json
import boto3
import requests

SSM = boto3.client("ssm", region_name="ca-central-1")
S3 = boto3.client("s3", region_name="ca-central-1")

def get_slack_webhook():
    name = os.environ.get("SLACK_SSM_PARAM", "/devsecops/slack_webhook")
    res = SSM.get_parameter(Name=name, WithDecryption=True)
    return res["Parameter"]["Value"]

def post_slack(text):
    webhook = get_slack_webhook()
    requests.post(webhook, json={"text": text})

def parse_bandit(bandit_json):
    try:
        data = json.loads(bandit_json)
        results = data.get("results", [])
        if not results:
            return None
        top = results[0]
        issue_text = top.get("issue_text", "Unknown issue")
        filename = top.get("filename","<unknown>")
        line = top.get("line_number", 0)
        code = top.get("test", "")
        return {"issue_text": issue_text, "filename": filename, "line": line, "test": code}
    except Exception as e:
        return {"error": str(e)}

def lambda_handler(event, context):
    bucket = event.get("bucket")
    key = event.get("key")

    if not bucket or not key:
        post_slack(":warning: ai-suggester invoked without bucket/key")
        return {"status": "bad-request"}

    obj = S3.get_object(Bucket=bucket, Key=key)
    bandit_json = obj["Body"].read().decode("utf-8")

    parsed = parse_bandit(bandit_json)
    if not parsed:
        post_slack(":white_check_mark: No Bandit findings")
        return {"status": "no-findings"}

    issue = parsed.get("issue_text", "")
    suggestion = ""

    if "SQL" in issue or "sql" in issue:
        suggestion = "Use parameterized queries; avoid formatting SQL strings with user input."

    else:
        suggestion = f"Review finding: {parsed.get('issue_text')} (File: {parsed.get('filename')}:{parsed.get('line')})"

    slack_text = (
        f"*Vulnerability*: {parsed.get('issue_text')}\n"
        f"*File*: {parsed.get('filename')}:{parsed.get('line')}\n"
        f"*Suggestion*: {suggestion}"
    )
    post_slack(slack_text)

    return {"status": "notified"}
